import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import httpx

app = FastAPI(title="OmniAI Private Backend", version="0.1.0")

MODEL_API_BASE = os.getenv("MODEL_API_BASE", "http://127.0.0.1:8001/v1")
MODEL_NAME = os.getenv("MODEL_NAME", "local-model")
MODEL_API_KEY = os.getenv("MODEL_API_KEY", "local-only")

class ChatRequest(BaseModel):
    message: str

class ChatResponse(BaseModel):
    reply: str

@app.get("/health")
async def health():
    return {"status": "ok", "service": "omniai-backend"}

@app.post("/api/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    if not request.message.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty")
    payload = {
        "model": MODEL_NAME,
        "messages": [
            {"role": "system", "content": "You are OmniAI, an independent assistant running on the owner's private infrastructure. Be accurate and clearly state limitations."},
            {"role": "user", "content": request.message}
        ],
        "temperature": 0.7
    }
    try:
        async with httpx.AsyncClient(timeout=110.0) as client:
            response = await client.post(
                f"{MODEL_API_BASE.rstrip('/')}/chat/completions",
                json=payload,
                headers={"Authorization": f"Bearer {MODEL_API_KEY}"}
            )
            response.raise_for_status()
            data = response.json()
            reply = data["choices"][0]["message"]["content"]
            return ChatResponse(reply=reply)
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Local model server unavailable: {exc}") from exc
    except (KeyError, IndexError, TypeError) as exc:
        raise HTTPException(status_code=502, detail="Unexpected response from local model server") from exc

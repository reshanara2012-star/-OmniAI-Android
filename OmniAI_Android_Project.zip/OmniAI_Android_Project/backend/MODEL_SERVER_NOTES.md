# Model server notes

Run a self-hosted OpenAI-compatible inference server on the dedicated GPU machine.
The starter backend expects the model endpoint at `MODEL_API_BASE` and uses `MODEL_NAME` as the deployed model identifier.

The correct model and serving configuration depend on GPU VRAM, desired context length, concurrency, model licence and quality targets. Do not expose the inference port publicly. Keep it on a private network and let the authenticated HTTPS gateway be the only public entry point.

package com.omniai.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

private val Ink = Color(0xFF090E1C)
private val Panel = Color(0xFF151E34)
private val Accent = Color(0xFF91A5FF)
private val Muted = Color(0xFF9AA8C5)

data class AiFeature(val title: String, val group: String, val description: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val features = listOf(
    AiFeature("Real-time video & world generation", "Create", "Generate video and immersive worlds through a connected self-hosted model.", Icons.Default.Movie),
    AiFeature("Interactive 3D & spatial environments", "Create", "Build and explore interactive 3D scenes.", Icons.Default.ViewInAr),
    AiFeature("Audio & voice synthesis", "Audio", "Generate natural speech and expressive audio.", Icons.Default.GraphicEq),
    AiFeature("Text-to-voice cloning", "Audio", "Create authorized voice variations from supplied samples.", Icons.Default.RecordVoiceOver),
    AiFeature("Voice cloning & dubbing", "Audio", "Dub recordings using voices you own or have permission to use.", Icons.Default.Translate),
    AiFeature("Instant music & sound effects", "Audio", "Generate original music and sound effects.", Icons.Default.MusicNote),
    AiFeature("Digital video avatars", "Create", "Create talking-avatar videos from approved assets.", Icons.Default.Face),
    AiFeature("Video editing & remixing", "Create", "Edit and transform user-provided videos.", Icons.Default.VideoSettings),
    AiFeature("Text-to-video & image-to-video", "Create", "Animate prompts and still images with a connected model.", Icons.Default.AutoAwesome),
    AiFeature("End-to-end software development", "Build", "Plan, write, test and package software projects.", Icons.Default.Terminal),
    AiFeature("Coding assistant", "Build", "Explain, generate, refactor and debug code.", Icons.Default.Code),
    AiFeature("Website builder", "Build", "Generate responsive websites and export project files.", Icons.Default.Language),
    AiFeature("Computer & browser use", "Automation", "Operate approved browser workflows with user confirmation.", Icons.Default.Public),
    AiFeature("Workflow automation", "Automation", "Connect services and run repeatable workflows.", Icons.Default.AccountTree),
    AiFeature("Advanced problem solving", "Intelligence", "Reason through difficult technical and research problems.", Icons.Default.Psychology),
    AiFeature("Protein folding & drug discovery", "Science", "Connect to specialist bioinformatics and molecular tools.", Icons.Default.Science),
    AiFeature("Real-time robotics control", "Robotics", "Connect to a secured robot gateway; compatible hardware is required.", Icons.Default.SmartToy),
    AiFeature("Weather", "Utilities", "Retrieve current conditions and forecasts from a data source.", Icons.Default.Cloud),
    AiFeature("Instant data analysis", "Intelligence", "Analyze datasets and generate charts and reports.", Icons.Default.QueryStats),
    AiFeature("Translation", "Utilities", "Translate text and files across supported languages.", Icons.Default.Translate)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OmniApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OmniApp(context: Context) {
    var selected by remember { mutableStateOf<AiFeature?>(null) }
    var search by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var backendUrl by remember { mutableStateOf(loadServer(context)) }
    var showSettings by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var chatAnswer by remember { mutableStateOf("") }
    var chatBusy by remember { mutableStateOf(false) }
    var chatError by remember { mutableStateOf("") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, background = Ink, surface = Panel,
        onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, null, tint = Accent)
                            Spacer(Modifier.width(9.dp))
                            Text("OmniAI", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(8.dp))
                            Surface(color = Color(0xFF1E3450), shape = RoundedCornerShape(20.dp)) {
                                Text("PRIVATE AI", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    color = Accent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Server settings") }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(selected = selected == null, onClick = { selected = null },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = selected?.group == "Build", onClick = { selected = features.first { it.group == "Build" } },
                        icon = { Icon(Icons.Default.Code, null) }, label = { Text("Build") })
                    NavigationBarItem(selected = selected?.group == "Create", onClick = { selected = features.first { it.group == "Create" } },
                        icon = { Icon(Icons.Default.AutoFixHigh, null) }, label = { Text("Create") })
                    NavigationBarItem(selected = false, onClick = { showSettings = true },
                        icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
                }
            }
        ) { padding ->
            if (selected == null) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 24.dp, top = 8.dp)
                ) {
                    item {
                        Column(
                            Modifier.fillMaxWidth()
                                .background(Brush.linearGradient(listOf(Color(0xFF23345E), Color(0xFF10182D))), RoundedCornerShape(22.dp))
                                .padding(20.dp)
                        ) {
                            Text("YOUR AI. YOUR SERVER.", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text("What shall we do today?", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Spacer(Modifier.height(6.dp))
                            Text("A private workspace for intelligence, creation and building.", color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(16.dp))
                            OutlinedTextField(
                                value = prompt, onValueChange = { prompt = it },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("Message your OmniAI server…") },
                                trailingIcon = {
                                    IconButton(enabled = prompt.isNotBlank() && !chatBusy,
                                        onClick = {
                                            val question = prompt.trim()
                                            prompt = ""
                                            chatBusy = true
                                            chatError = ""
                                            thread {
                                                try {
                                                    val result = sendChat(backendUrl, question)
                                                    android.os.Handler(context.mainLooper).post {
                                                        chatAnswer = result
                                                        chatBusy = false
                                                    }
                                                } catch (e: Exception) {
                                                    android.os.Handler(context.mainLooper).post {
                                                        chatError = e.message ?: "Could not reach your OmniAI server."
                                                        chatBusy = false
                                                    }
                                                }
                                            }
                                        }) { Icon(Icons.Default.ArrowUpward, "Send", tint = Accent) }
                                },
                                shape = RoundedCornerShape(16.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Accent, unfocusedBorderColor = Muted,
                                    focusedTextColor = Color.White, unfocusedTextColor = Color.White
                                )
                            )
                            if (chatBusy) { Spacer(Modifier.height(8.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()) }
                            if (chatAnswer.isNotBlank()) {
                                Spacer(Modifier.height(12.dp))
                                Text("OMNIAI", color = Accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text(chatAnswer, color = Color.White, fontSize = 14.sp)
                            }
                            if (chatError.isNotBlank()) {
                                Spacer(Modifier.height(8.dp))
                                Text(chatError, color = Color(0xFFFFA6A6), fontSize = 12.sp)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(if (backendUrl.isBlank()) "Connect your dedicated server in Settings to enable chat."
                                else "Server configured: ${backendUrl.trimEnd('/')}  •  AI replies require your server to be running.",
                                color = Muted, fontSize = 10.sp)
                        }
                    }
                    item {
                        Text("Explore capabilities", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = search, onValueChange = { search = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Search 20 capabilities") },
                            leadingIcon = { Icon(Icons.Default.Search, null) },
                            singleLine = true, shape = RoundedCornerShape(14.dp)
                        )
                    }
                    val filtered = features.filter { it.title.contains(search, true) || it.group.contains(search, true) }
                    items(filtered) { feature -> FeatureCard(feature) { selected = feature } }
                    item {
                        Text("OmniAI is self-hosted by design. Features become operational as their matching models and services are installed on your server.",
                            color = Muted, fontSize = 12.sp)
                    }
                }
            } else {
                Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
                    TextButton(onClick = { selected = null }) {
                        Icon(Icons.Default.ArrowBack, null); Text("  All capabilities")
                    }
                    Spacer(Modifier.height(18.dp))
                    Icon(selected!!.icon, null, tint = Accent, modifier = Modifier.size(42.dp))
                    Spacer(Modifier.height(14.dp))
                    Text(selected!!.title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(selected!!.description, color = Muted)
                    Spacer(Modifier.height(22.dp))
                    Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Service status", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text("Waiting for this service to be installed on your OmniAI server", color = Accent)
                            Spacer(Modifier.height(8.dp))
                            Text("This capability needs its own self-hosted model or tool, server endpoint, and permission settings before it can run.",
                                color = Muted, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        if (showSettings) {
            var editedUrl by remember { mutableStateOf(backendUrl) }
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("Your OmniAI server") },
                text = {
                    Column {
                        Text("Enter the HTTPS address of your dedicated server's OmniAI backend.",
                            color = Muted, fontSize = 13.sp)
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = editedUrl, onValueChange = { editedUrl = it },
                            label = { Text("Server URL") },
                            placeholder = { Text("https://your-server.example.com") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                            singleLine = true
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("Do not enter model-provider API keys here. Keep secrets on your server.",
                            color = Muted, fontSize = 11.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        backendUrl = editedUrl.trim().trimEnd('/')
                        saveServer(context, backendUrl)
                        showSettings = false
                    }) { Text("Save server") }
                },
                dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } }
            )
        }
        if (showAbout) {
            AlertDialog(onDismissRequest = { showAbout = false }, title = { Text("About OmniAI") },
                text = { Text("OmniAI is an independent, self-hosted AI project. This Android app is the phone interface. Your dedicated server must be installed and configured to provide AI responses and specialist capabilities.") },
                confirmButton = { TextButton(onClick = { showAbout = false }) { Text("OK") } })
        }
    }
}

@Composable
fun FeatureCard(feature: AiFeature, onClick: () -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Color(0xFF222D4C), shape = RoundedCornerShape(12.dp)) {
                Icon(feature.icon, null, tint = Accent, modifier = Modifier.padding(11.dp).size(23.dp))
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(feature.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(feature.group, color = Muted, fontSize = 11.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

private fun loadServer(context: Context): String =
    context.getSharedPreferences("omniai_settings", Context.MODE_PRIVATE).getString("server_url", "") ?: ""

private fun saveServer(context: Context, value: String) {
    context.getSharedPreferences("omniai_settings", Context.MODE_PRIVATE).edit().putString("server_url", value).apply()
}

private fun sendChat(baseUrl: String, prompt: String): String {
    require(baseUrl.startsWith("https://")) { "Set your server URL to an HTTPS address in Settings first." }
    val connection = (URL(baseUrl.trimEnd('/') + "/api/chat").openConnection() as HttpURLConnection)
    connection.requestMethod = "POST"
    connection.connectTimeout = 15000
    connection.readTimeout = 120000
    connection.doOutput = true
    connection.setRequestProperty("Content-Type", "application/json")
    connection.outputStream.use { it.write(JSONObject().put("message", prompt).toString().toByteArray(Charsets.UTF_8)) }
    val code = connection.responseCode
    val stream = if (code in 200..299) connection.inputStream else connection.errorStream
    val body = stream.bufferedReader().use { it.readText() }
    connection.disconnect()
    if (code !in 200..299) throw IllegalStateException("Server returned HTTP $code: $body")
    return JSONObject(body).optString("reply", "The server returned no reply.")
}

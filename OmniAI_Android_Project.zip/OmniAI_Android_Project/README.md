# OmniAI — Android app + private backend starter

## What this project is
A native Kotlin/Jetpack Compose Android application foundation for OmniAI, plus a small FastAPI backend that forwards chat requests to a **self-hosted, OpenAI-compatible local model server** (for example, vLLM).

The Android app includes:
- A dark futuristic dashboard designed for phone screens
- All 20 requested capability areas
- Search and capability detail screens
- A setting to save your own HTTPS OmniAI server URL
- A chat request wired to `POST /api/chat`

The backend includes:
- `GET /health`
- `POST /api/chat`
- A local-model adapter using an OpenAI-compatible API
- No ChatGPT, Gemini or Claude dependency

## Honest implementation status
This is a starter project, **not a finished AI product**.
- The Android UI and server URL setting are implemented in source.
- The Android chat request is wired to the backend contract.
- The FastAPI backend is implemented as a basic local-model gateway.
- You must install and configure a self-hosted model server, set the correct model ID, deploy the API behind HTTPS, and test the connection.
- The other 19 capability areas are currently feature placeholders; each needs its own self-hosted model/tool, job processing, storage, and safety controls.
- No APK is included. This workspace does not have the Android SDK/Gradle build toolchain, so compilation and device testing have not been performed.

## Android build
1. Install Android Studio and JDK 17 on a computer.
2. Open this folder in Android Studio.
3. Install Android SDK Platform 35 when prompted.
4. Allow Gradle sync.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will generate a debug APK under `app/build/outputs/apk/debug/`.

Minimum Android version: Android 8.0 (API 26). This includes Android 13 devices such as the Samsung Galaxy A03s.

## Backend API contract
Set the server URL in the app to your public HTTPS address, for example `https://ai.example.com`.

The app sends:
```json
{"message":"Hello OmniAI"}
```
to `POST /api/chat` and expects:
```json
{"reply":"Hello! How can I help?"}
```

Never expose the backend directly on an open internet port. Put it behind HTTPS, authentication, rate limiting and a firewall before connecting a phone over the internet. Add user authentication before real-world deployment; this starter intentionally does not pretend to provide production authentication.

## Run the backend gateway
On the server, configure a self-hosted OpenAI-compatible inference endpoint. Copy `.env.example` to `.env` and set:
- `MODEL_API_BASE`
- `MODEL_NAME`
- `MODEL_API_KEY` (only if your local inference server requires it)

Then run:
```bash
docker compose up --build -d
```
The sample compose file binds the API to localhost only. A reverse proxy with TLS and authentication must be configured separately before remote access.

## Suggested inference server
Use a compatible local inference engine such as vLLM. The backend defaults to `http://host.docker.internal:8001/v1`, which assumes the model server listens on port 8001 on the same host. Adjust this for your actual deployment.

## Roadmap
1. Deploy local language model + secure gateway.
2. Add authentication and per-user sessions.
3. Add conversation history and private memory.
4. Add coding and document-analysis agents.
5. Add image, speech, audio and video models.
6. Add 3D tools, data analysis and translation.
7. Add browser/workflow automation with confirmation gates.
8. Add scientific workloads and robotics only after specialist validation and hardware safety design.


## Build APK using GitHub Actions (no Android SDK on your computer required)
1. Create a GitHub account if you do not already have one.
2. Create a new repository named `OmniAI-Android`.
3. Upload the contents of this project ZIP to the repository (keep the `.github/workflows/android-apk.yml` file and its folders).
4. Open the repository's **Actions** tab and select **Build OmniAI Android APK**.
5. Press **Run workflow**. Wait for the build to finish.
6. Open the completed workflow run and download the `OmniAI-debug-apk` artifact.
7. Extract the downloaded artifact ZIP; it contains the debug APK. Transfer the APK to your Samsung Galaxy A03s and install it. Android may ask you to allow installation from that source.

This workflow is a build configuration, not proof that a build has succeeded. The APK exists only after GitHub reports a successful run. A debug APK is suitable for personal testing, not public Play Store distribution.
